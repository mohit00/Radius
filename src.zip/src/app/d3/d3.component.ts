import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';

@Component({
  selector: 'app-d3',
  templateUrl: './d3.component.html',
  styleUrls: ['./d3.component.scss']
})
export class D3Component implements OnInit {
  constructor() { }
  radius: any = 10;
  ngOnInit() {
  }
// tslint:disable-next-line: use-life-cycle-interface
  ngAfterContentInit() {
   
// tslint:disable-next-line: one-variable-per-declaration
 
}
test(){
  alert("dsad")
}
}
