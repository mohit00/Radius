import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-conference',
  templateUrl: './video-conference.component.html',
  styleUrls: ['./video-conference.component.scss']
})
export class VideoConferenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
