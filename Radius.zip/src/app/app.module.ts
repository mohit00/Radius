import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {BrowserModule} from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule,HTTP_INTERCEPTORS  } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import {LoaderInterceptor} from '../app/interceptor/loaderiterceptor'
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.routing';
import { NavbarModule } from './shared/navbar/navbar.module';
import { FooterModule } from './shared/footer/footer.module';
import { SidebarModule } from './sidebar/sidebar.module';
import {NewsletterService} from '../app/newsletterService';
import { AppComponent } from './app.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import {  ModalModule , AlertModule, TabsModule ,BsDatepickerModule    } from 'ngx-bootstrap';

import { DeviceProvisioningDialogComponent } from './device-provisioning/device-provisioning-dialog/device-provisioning-dialog.component';
import { LoginComponent } from './login/login.component';
import {AuthService} from './auth.service';
import {WebserModel} from './Service.model';
import { AttributeDialogComponent } from './attribute-template/attribute-dialog/attribute-dialog.component';
import { EventDialogComponent } from './event-template/event-dialog/event-dialog.component';
import { CommandDialogComponent } from './command-template/command-dialog/command-dialog.component';
import { DeviceDialogComponent } from './device-template/device-dialog/device-dialog.component';
import { SuccessDialogComponent } from './dialog/success-dialog/success-dialog.component';
import { ArrtibuteSelectComponent } from './arrtibute-select/arrtibute-select.component';
import { ChangeStatusComponent } from './change-status/change-status.component';
import { MigrateDialogComponent } from './migrate-dialog/migrate-dialog.component';
import { AddFieldDialogComponent } from './add-field-dialog/add-field-dialog.component';
import { AccountDialogComponent } from './Account/account/account-dialog/account-dialog.component'
import {AccountService} from './Account/account.service';

@NgModule({
  imports: [BrowserModule.withServerTransition({ appId: 'serverApp' }),
    BrowserAnimationsModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    NavbarModule,
    FooterModule,
    SidebarModule, TabsModule.forRoot(), 
    AppRoutingModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    ModalModule.forRoot(), AlertModule.forRoot() , BsDatepickerModule.forRoot()
  ],
   declarations: [
    AppComponent,AccountDialogComponent,
    AdminLayoutComponent,
    DeviceProvisioningDialogComponent,
    LoginComponent,
    AttributeDialogComponent,
    EventDialogComponent,
    CommandDialogComponent,
    DeviceDialogComponent,
    SuccessDialogComponent,
    ArrtibuteSelectComponent,ChangeStatusComponent, MigrateDialogComponent, AddFieldDialogComponent
  
  ],
  entryComponents: [
    DeviceDialogComponent,AccountDialogComponent,
    DeviceProvisioningDialogComponent, AttributeDialogComponent,
    EventDialogComponent, CommandDialogComponent, 
    SuccessDialogComponent,ChangeStatusComponent,MigrateDialogComponent, AddFieldDialogComponent
  ],
  providers: [NewsletterService, AuthService, WebserModel,HttpClient, AccountService,
       { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
